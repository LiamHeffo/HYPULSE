-- CEA Gas model made automatically by PITOT3

model = "CEAGas"

CEAGas = {
  mixtureName = "driver_gas",
  speciesList = {'He'},
  reactants = {He = 1.0},
  inputUnits = 'moles',
  withIons = false,
  trace = 1e-06
}